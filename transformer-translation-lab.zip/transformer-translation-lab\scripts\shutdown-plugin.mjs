// dev サーバ (Vite) をブラウザ側から確実に終了させるための Vite プラグイン．
// 「終了の仕方がわかりにくい」「タブを閉じても npm run dev が残る」を解消する．
//
// 2 つの経路で終了する．
//   1. 明示終了: 画面の「終了」ボタンが /__quit を叩く．受け取ったら即座に終了する．
//   2. 自動終了: ブラウザが一定間隔で /__heartbeat を送る．最後の heartbeat から
//      GRACE_MS を過ぎても次が来なければ「タブが閉じられた」とみなして終了する．
//      リロードや短時間の中断では次の heartbeat がすぐ届くので落ちない．
//
// process.exit(0) で抜けると，親の scripts/dev.mjs が child の exit を受け取り，
// キャッシュ掃除 (clean) を実行してからプロセスを終える．
// dev サーバ専用の機能なので，本番ビルド (vite build / preview) には影響しない．

// 最後の heartbeat からこの時間が過ぎたら自動終了する (ms)．
// クライアントの送信間隔 (2000ms) より十分長くし，リロードで誤終了しないようにする．
const GRACE_MS = 6000

export function browserShutdownPlugin() {
  let timer
  let closing = false

  function shutdown(reason, server) {
    if (closing) return
    closing = true
    console.log(`\n[dev] ${reason} により dev サーバを終了する．`)
    const bye = () => process.exit(0)
    // サーバを閉じてから抜ける．close がハングしても保険で必ず抜ける．
    Promise.resolve(server.close?.()).then(bye, bye)
    setTimeout(bye, 400).unref?.()
  }

  // heartbeat を受け取るたびに自動終了タイマーを張り直す (dead man's switch)．
  function armTimer(server) {
    if (timer) clearTimeout(timer)
    timer = setTimeout(() => shutdown('ブラウザ切断 (タブを閉じた)', server), GRACE_MS)
    timer.unref?.()
  }

  return {
    name: 'browser-shutdown',
    apply: 'serve', // dev サーバ (vite / vite dev) のときだけ有効化する．
    configureServer(server) {
      server.middlewares.use((req, res, next) => {
        if (req.url === '/__quit') {
          res.statusCode = 200
          res.setHeader('content-type', 'text/plain; charset=utf-8')
          res.end('bye')
          shutdown('終了ボタン', server)
          return
        }
        if (req.url === '/__heartbeat') {
          armTimer(server)
          res.statusCode = 204
          res.end()
          return
        }
        next()
      })
    },
  }
}
