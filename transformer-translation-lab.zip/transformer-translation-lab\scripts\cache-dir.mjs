// Vite の依存最適化キャッシュを Dropbox 配下ではなく OS の一時ディレクトリに置く．
// 狙いは 2 つ．
//   1. Dropbox の同期ロックによる EBUSY (deps フォルダを消せない) を根絶する．
//   2. プロジェクトフォルダに .vite キャッシュを一切残さない．
//      これにより，フォルダをまとめて zip / アップロードしてもゴミが混ざらない．
//
// process.cwd() を基準にするのは，Vite が設定ファイルを esbuild で一時バンドルする際に
// import.meta.url が一時パスを指してしまう問題を避けるため．dev / build いずれも
// プロジェクトルートで実行される前提．
import os from 'node:os'
import path from 'node:path'
import crypto from 'node:crypto'

const projectRoot = process.cwd()
const projectId = crypto.createHash('md5').update(projectRoot).digest('hex').slice(0, 12)

export const cacheDir = path.join(os.tmpdir(), `vite-cache-${projectId}`)
