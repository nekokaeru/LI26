// dev サーバ起動ラッパー．
// Vite を子プロセスで起動し，終了時 (Ctrl+C・通常終了・エラーいずれの経路でも)
// 必ずキャッシュを掃除する．これで「アプリが落ちるときにゴミを残さない」を保証する．
import { spawn } from 'node:child_process'
import { rmSync } from 'node:fs'
import path from 'node:path'
import { cacheDir } from './cache-dir.mjs'

const projectRoot = process.cwd()
const viteBin = path.join(projectRoot, 'node_modules', 'vite', 'bin', 'vite.js')

// 終了時に消すもの（キャッシュのみ．dist は成果物なので残す）．
// node_modules/.vite は本来 cacheDir 移設で生成されないが，旧環境の残骸も掃除する．
const junk = [cacheDir, path.join(projectRoot, 'node_modules', '.vite')]

let cleaned = false
function clean() {
  if (cleaned) return
  cleaned = true
  for (const p of junk) {
    try {
      rmSync(p, { recursive: true, force: true })
    } catch {
      // ロック等で消せなくても致命的ではないので握りつぶす．
    }
  }
}

const child = spawn(process.execPath, [viteBin, '--host', '127.0.0.1'], {
  stdio: 'inherit',
  cwd: projectRoot,
})

child.on('exit', (code) => process.exit(code ?? 0))
child.on('error', (err) => {
  console.error(err)
  process.exit(1)
})

// シグナルは子へ転送する．子が終われば child 'exit' -> process.exit -> 'exit' で clean が走る．
for (const sig of ['SIGINT', 'SIGTERM', 'SIGHUP']) {
  process.on(sig, () => {
    try {
      child.kill(sig)
    } catch {
      // ignore
    }
  })
}

// どの経路で抜けても最後に必ず掃除する（同期処理のみ許される場所なので rmSync を使う）．
process.on('exit', clean)
