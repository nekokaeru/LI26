// 手動フルクリーン．dist とキャッシュ類をまとめて削除する．
// アップロード前に `npm run clean` で成果物・キャッシュを一掃したいとき用．
import { rmSync } from 'node:fs'
import path from 'node:path'
import { cacheDir } from './cache-dir.mjs'

const projectRoot = process.cwd()
const targets = [
  cacheDir,
  path.join(projectRoot, 'node_modules', '.vite'),
  path.join(projectRoot, 'dist'),
]

for (const p of targets) {
  try {
    rmSync(p, { recursive: true, force: true })
    console.log('removed', p)
  } catch (err) {
    console.error('skip  ', p, '-', err.message)
  }
}
