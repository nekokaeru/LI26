import "./styles.css";
import { examples } from "./miniTransformer";
import type { AttentionHead, DecodeStep, ModelToken, TransformerTrace, WorkerResponse } from "./miniTransformer";

const app = document.querySelector<HTMLDivElement>("#app");

if (!app) {
  throw new Error("Missing app root");
}

app.innerHTML = `
  <main class="shell">
    <section class="topbar">
      <div>
        <p class="eyebrow">Encoder-Decoder Demo</p>
        <h1>Transformer Translation Lab</h1>
      </div>
      <div class="topbar-actions">
        <div class="status-pill" id="statusPill">Worker idle</div>
        ${import.meta.env.DEV ? `<button id="quitButton" class="quit-button" type="button" title="Stop the dev server">■ Quit</button>` : ""}
      </div>
    </section>

    <section class="workspace">
      <aside class="control-panel">
        <label class="field-label" for="exampleSelect">Preset sentence</label>
        <select id="exampleSelect" class="select"></select>

        <label class="field-label" for="inputText">Japanese input</label>
        <textarea id="inputText" class="input" rows="3"></textarea>

        <div class="button-row">
          <button id="runButton" class="primary-button" type="button">Run</button>
          <button id="playButton" class="icon-button" type="button" aria-label="Pause or play">Pause</button>
        </div>

        <div class="button-row">
          <button id="prevButton" class="ghost-button" type="button">Prev</button>
          <button id="nextButton" class="ghost-button" type="button">Next</button>
        </div>

        <label class="field-label" for="speedRange">Replay speed</label>
        <input id="speedRange" class="range" type="range" min="140" max="1200" value="520" step="20" />

        <div class="segmented" role="tablist" aria-label="Attention head">
          <button class="segment active" data-head="0" type="button">Lexical head</button>
          <button class="segment" data-head="1" type="button">Syntax head</button>
        </div>

        <div class="source-note">
          <strong>PPT focus</strong>
          <span>Shifted right decoding, encoder self-attention, masked self-attention, and cross-attention.</span>
        </div>
      </aside>

      <section class="stage">
        <div class="stage-header">
          <div>
            <p class="eyebrow">Live Run</p>
            <h2 id="translationTitle">Ready</h2>
          </div>
          <div class="step-counter" id="stepCounter">0 / 0</div>
        </div>

        <div class="token-lane source-lane">
          <div class="lane-label">Japanese tokens</div>
          <div class="token-row" id="sourceTokens"></div>
        </div>

        <div class="transformer-core">
          <div class="core-column encoder-column">
            <div class="core-title">Encoder</div>
            <div class="layer active">Input embedding + position</div>
            <div class="layer active">Self-attention</div>
            <div class="layer">Feed forward</div>
          </div>

          <svg id="attentionSvg" class="attention-svg" viewBox="0 0 1000 280" preserveAspectRatio="none"></svg>

          <div class="core-column decoder-column">
            <div class="core-title">Decoder</div>
            <div class="layer active">Shifted right input</div>
            <div class="layer active">Masked self-attention</div>
            <div class="layer active">Cross-attention</div>
            <div class="layer">Output projection</div>
          </div>
        </div>

        <div class="token-lane output-lane">
          <div class="lane-label">English output</div>
          <div class="token-row" id="outputTokens"></div>
        </div>
      </section>

      <aside class="inspector">
        <div class="result-box">
          <span class="mini-label">Generated translation</span>
          <strong id="finalText">-</strong>
        </div>

        <div class="step-box">
          <span class="mini-label">Decoder input (shifted right)</span>
          <div id="shiftedRight" class="shifted-row"></div>
        </div>

        <div>
          <div class="panel-heading">
            <h3>Token probabilities</h3>
            <span id="predictedToken">-</span>
          </div>
          <div id="probabilities" class="probabilities"></div>
        </div>

        <div class="heatmap-section">
          <div class="panel-heading">
            <h3>Encoder self-attention</h3>
            <span id="encoderHeadLabel">Lexical</span>
          </div>
          <div id="encoderHeatmap" class="heatmap"></div>
        </div>

        <div class="heatmap-section">
          <div class="panel-heading">
            <h3>Cross-attention</h3>
            <span id="crossHeadLabel">Lexical</span>
          </div>
          <div id="crossHeatmap" class="heatmap compact"></div>
        </div>
      </aside>
    </section>
  </main>
`;

const worker = new Worker(new URL("./transformerWorker.ts", import.meta.url), { type: "module" });
const elements = {
  statusPill: byId("statusPill"),
  exampleSelect: byId<HTMLSelectElement>("exampleSelect"),
  inputText: byId<HTMLTextAreaElement>("inputText"),
  runButton: byId<HTMLButtonElement>("runButton"),
  playButton: byId<HTMLButtonElement>("playButton"),
  prevButton: byId<HTMLButtonElement>("prevButton"),
  nextButton: byId<HTMLButtonElement>("nextButton"),
  speedRange: byId<HTMLInputElement>("speedRange"),
  translationTitle: byId("translationTitle"),
  stepCounter: byId("stepCounter"),
  sourceTokens: byId("sourceTokens"),
  outputTokens: byId("outputTokens"),
  attentionSvg: byId<SVGSVGElement>("attentionSvg"),
  finalText: byId("finalText"),
  shiftedRight: byId("shiftedRight"),
  probabilities: byId("probabilities"),
  predictedToken: byId("predictedToken"),
  encoderHeatmap: byId("encoderHeatmap"),
  crossHeatmap: byId("crossHeatmap"),
  encoderHeadLabel: byId("encoderHeadLabel"),
  crossHeadLabel: byId("crossHeadLabel")
};

let requestId = 0;
let trace: TransformerTrace | null = null;
let currentStep = 0;
let playing = true;
let selectedHead = 0;
let replayTimer: number | undefined;

elements.exampleSelect.innerHTML = examples
  .map((example, index) => `<option value="${index}">${escapeHtml(example.label)}</option>`)
  .join("");
elements.inputText.value = examples[0].input;

elements.exampleSelect.addEventListener("change", () => {
  const selected = examples[Number(elements.exampleSelect.value)] ?? examples[0];
  elements.inputText.value = selected.input;
  runModel();
});

elements.runButton.addEventListener("click", runModel);
elements.playButton.addEventListener("click", () => {
  if (!playing && trace && currentStep >= trace.steps.length) {
    currentStep = 0;
  }
  playing = !playing;
  elements.playButton.textContent = playing ? "Pause" : "Play";
  if (playing) setStatus("Replay active");
  scheduleReplay();
});
elements.prevButton.addEventListener("click", () => {
  if (!trace) return;
  currentStep = Math.max(0, currentStep - 1);
  playing = false;
  elements.playButton.textContent = "Play";
  render();
});
elements.nextButton.addEventListener("click", () => {
  if (!trace) return;
  currentStep = Math.min(trace.steps.length, currentStep + 1);
  playing = false;
  elements.playButton.textContent = "Play";
  render();
});
elements.speedRange.addEventListener("input", scheduleReplay);
document.querySelectorAll<HTMLButtonElement>(".segment").forEach((button) => {
  button.addEventListener("click", () => {
    selectedHead = Number(button.dataset.head ?? 0);
    document.querySelectorAll(".segment").forEach((item) => item.classList.remove("active"));
    button.classList.add("active");
    render();
  });
});

worker.onmessage = (event: MessageEvent<WorkerResponse>) => {
  if (event.data.id !== requestId) return;
  if (event.data.type === "started") {
    setStatus("Worker running");
    return;
  }
  if (event.data.type === "error") {
    setStatus("Worker error");
    elements.translationTitle.textContent = event.data.message;
    return;
  }

  trace = event.data.trace;
  currentStep = Math.min(1, trace.steps.length);
  playing = true;
  elements.playButton.textContent = "Pause";
  setStatus("Replay active");
  render();
  scheduleReplay();
};

runModel();

// dev サーバの終了制御 (本番ビルドには含めない)．
//   - 終了ボタン: /__quit を叩いて即座にサーバを止める．
//   - ハートビート: 一定間隔で /__heartbeat を送る．タブを閉じて送信が途切れると，
//     サーバ側が「切断」とみなして自動終了する．これで npm run dev が残らない．
if (import.meta.env.DEV) {
  setupDevShutdown();
}

function setupDevShutdown() {
  const heartbeat = () => {
    void fetch("/__heartbeat", { method: "POST", keepalive: true }).catch(() => {});
  };
  heartbeat();
  window.setInterval(heartbeat, 2000);

  const quitButton = document.getElementById("quitButton");
  quitButton?.addEventListener("click", () => {
    void fetch("/__quit", { method: "POST" }).catch(() => {});
    showShutdownOverlay();
  });
}

function showShutdownOverlay() {
  const overlay = document.createElement("div");
  overlay.className = "shutdown-overlay";
  overlay.innerHTML = `
    <div class="shutdown-card">
      <strong>Dev server stopped</strong>
      <span>You can close this tab. To start again, run <code>npm run dev</code>.</span>
    </div>
  `;
  document.body.appendChild(overlay);
}

function runModel() {
  requestId += 1;
  trace = null;
  currentStep = 0;
  clearReplay();
  setStatus("Worker queued");
  elements.translationTitle.textContent = "Encoding...";
  worker.postMessage({ id: requestId, input: elements.inputText.value });
}

function scheduleReplay() {
  clearReplay();
  if (!playing || !trace) return;
  replayTimer = window.setTimeout(() => {
    if (!trace) return;
    if (currentStep >= trace.steps.length) {
      playing = false;
      elements.playButton.textContent = "Play";
      setStatus("Replay complete");
      render();
      return;
    }
    currentStep += 1;
    render();
    scheduleReplay();
  }, Number(elements.speedRange.value));
}

function clearReplay() {
  if (replayTimer !== undefined) window.clearTimeout(replayTimer);
}

function render() {
  if (!trace) return;
  const visibleSteps = trace.steps.slice(0, currentStep);
  const activeStep = visibleSteps[visibleSteps.length - 1];
  const headLabel = selectedHead === 0 ? "Lexical" : "Syntax";

  elements.translationTitle.textContent = trace.finalText;
  elements.stepCounter.textContent = `${currentStep} / ${trace.steps.length}`;
  elements.finalText.textContent = trace.finalText;
  elements.predictedToken.textContent = activeStep ? activeStep.predicted.text : "-";
  elements.encoderHeadLabel.textContent = headLabel;
  elements.crossHeadLabel.textContent = headLabel;

  renderTokenRow(elements.sourceTokens, trace.sourceTokens, "source", activeStep?.encoderPulse);
  renderTokenRow(elements.outputTokens, visibleSteps.map((step) => step.predicted), "output");
  renderShifted(activeStep);
  renderProbabilities(activeStep);
  renderHeatmap(elements.encoderHeatmap, trace.encoder.selfAttention[selectedHead], trace.sourceTokens, trace.sourceTokens);
  renderHeatmap(
    elements.crossHeatmap,
    activeStep?.crossAttention[selectedHead],
    trace.sourceTokens,
    activeStep ? [{ ...activeStep.predicted, text: "query" }] : []
  );
  renderAttentionSvg(trace, activeStep, visibleSteps.length);
}

function renderTokenRow(
  container: HTMLElement,
  tokens: ModelToken[],
  variant: "source" | "output",
  pulse?: number[]
) {
  container.innerHTML = tokens.map((token, index) => {
    const heat = pulse?.[index] ?? 0;
    return `
      <span class="token ${variant}" style="--heat:${heat.toFixed(3)}">
        <strong>${escapeHtml(token.text)}</strong>
        <small>${escapeHtml(token.gloss)}</small>
      </span>
    `;
  }).join("");
}

function renderShifted(step?: DecodeStep) {
  if (!step) {
    elements.shiftedRight.innerHTML = "";
    return;
  }
  elements.shiftedRight.innerHTML = step.shiftedRight
    .map((token) => `<span>${escapeHtml(token)}</span>`)
    .join("");
}

function renderProbabilities(step?: DecodeStep) {
  if (!step) {
    elements.probabilities.innerHTML = "";
    return;
  }

  elements.probabilities.innerHTML = step.topK.map((candidate) => `
    <div class="probability-row">
      <span>${escapeHtml(candidate.token)}</span>
      <div class="probability-track">
        <i style="width:${Math.max(4, candidate.probability * 100).toFixed(2)}%"></i>
      </div>
      <b>${Math.round(candidate.probability * 100)}%</b>
    </div>
  `).join("");
}

function renderHeatmap(
  container: HTMLElement,
  head: AttentionHead | undefined,
  columns: ModelToken[],
  rows: ModelToken[]
) {
  if (!head || rows.length === 0 || columns.length === 0) {
    container.innerHTML = `<span class="empty">No attention yet</span>`;
    return;
  }

  const columnStyle = `grid-template-columns: 76px repeat(${columns.length}, minmax(34px, 1fr));`;
  const header = `<span></span>${columns.map((token) => `<span class="axis">${escapeHtml(token.text)}</span>`).join("")}`;
  const body = rows.map((row, rowIndex) => {
    const cells = columns.map((_, columnIndex) => {
      const value = head.weights[rowIndex]?.[columnIndex] ?? 0;
      return `<span class="cell" style="--value:${value.toFixed(4)}">${Math.round(value * 100)}</span>`;
    }).join("");
    return `<span class="axis row-axis">${escapeHtml(row.text)}</span>${cells}`;
  }).join("");

  container.innerHTML = `<div class="heatmap-grid" style="${columnStyle}">${header}${body}</div>`;
}

function renderAttentionSvg(modelTrace: TransformerTrace, step: DecodeStep | undefined, outputCount: number) {
  if (!step) {
    elements.attentionSvg.innerHTML = "";
    return;
  }

  const sourceCount = Math.max(1, modelTrace.sourceTokens.length);
  const targetX = 780;
  const targetY = 228;
  const lines = step.crossAttention[selectedHead].weights[0]
    .map((weight, index) => {
      const x1 = 90 + (index / Math.max(1, sourceCount - 1)) * 360;
      const y1 = 45;
      const width = 1 + weight * 10;
      const opacity = 0.12 + weight * 0.78;
      const bend = 80 + outputCount * 7;
      return `
        <path d="M ${x1.toFixed(1)} ${y1} C ${(x1 + bend).toFixed(1)} 120, ${(targetX - bend).toFixed(1)} 155, ${targetX} ${targetY}"
          fill="none"
          stroke="rgba(55, 230, 205, ${opacity.toFixed(3)})"
          stroke-width="${width.toFixed(2)}"
          stroke-linecap="round" />
      `;
    })
    .join("");

  const nodes = `
    <circle cx="${targetX}" cy="${targetY}" r="13" fill="#f7c948" />
    <circle cx="${targetX}" cy="${targetY}" r="24" fill="none" stroke="rgba(247,201,72,.45)" stroke-width="2">
      <animate attributeName="r" values="18;31;18" dur="1.4s" repeatCount="indefinite" />
      <animate attributeName="opacity" values=".85;.18;.85" dur="1.4s" repeatCount="indefinite" />
    </circle>
  `;

  elements.attentionSvg.innerHTML = `<g>${lines}${nodes}</g>`;
}

function setStatus(text: string) {
  elements.statusPill.textContent = text;
}

function byId<T extends HTMLElement | SVGSVGElement = HTMLElement>(id: string): T {
  const element = document.getElementById(id);
  if (!element) throw new Error(`Missing element #${id}`);
  return element as T;
}

function escapeHtml(value: string) {
  return value
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}
