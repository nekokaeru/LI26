# Transformer Translation Lab
Naoki Mori
A small encoder-decoder Transformer visualization demo that translates short Japanese inputs into English.

Japanese README: [README.md](./README.md)

## Purpose

This app is an educational tool designed to explain how a Transformer processes a translation task in the “Language Informatics” course. It runs a tiny model inside a Web Worker and visualizes:

- encoder self-attention
- shifted-right decoder input
- masked decoder self-attention
- encoder-decoder cross-attention
- each autoregressive decoding step
- simplified token probability bars

It does not load a large pretrained model. Everything runs locally in the browser.

## Run

```bash
npm install
npm run dev
```

`pnpm` also works (`pnpm install && pnpm run dev`).

Then open:

```text
http://127.0.0.1:5173/
```

## Stopping the dev server

Stop the dev server in any of these ways. The cache is cleaned up automatically in every case.

- Click the "Quit" button at the top right of the page. The server stops immediately and shows that the tab can be closed.
- Close the browser tab (or window). Once the connection drops, the server shuts down automatically a few seconds later. A reload does not stop it.
- Press Ctrl+C in the terminal.

The Quit button and the close-tab auto-shutdown are dev-only features and are not included in a production build.

## Build

```bash
npm run build
```

When the project is inside a synced folder such as Dropbox, Vite may fail with `EPERM` if `dist` is locked while it tries to remove old `dist/assets` files. Wait for syncing to finish, or run `npm run clean` to remove `dist` and the caches before building again.

## Cache and cleanup

Vite's dependency-optimization cache is stored in the OS temp directory instead of inside the project (`node_modules\.vite`). This avoids `EBUSY` on synced folders like Dropbox and never leaves a `.vite` cache in the project folder.

- `npm run dev` removes this cache automatically when it exits (Ctrl+C or normal exit).
- `npm run clean` removes `dist` as well as the caches.

Run `npm run clean` before zipping or uploading the folder so no cache or build output is left behind.

## Educational Simplifications

This demo is built to explain Transformer computation and visualization. It is not intended to behave like a general-purpose machine translation system.

The main simplifications are:

- The vocabulary is limited to a small set of demo words.
- Supported Japanese inputs are the preset sentences and short sentences close to them.
- The tokenizer uses longest-match dictionary lookup, then falls back to one unknown token per character.
- The English target plan is produced by a small rule-based sentence-pattern detector.
- Embeddings are not pretrained. They are deterministic small vectors generated from each token's concept and role.
- Attention uses scaled dot-product attention, but role-based and source-alignment biases are added to make the visualization easier to read.
- Token probabilities are a softmax over internal demo scores. They should not be interpreted as calibrated model confidence.
- Grammar coverage is intentionally minimal. It handles cases such as `I am`, `You are`, and third-person singular forms like `is`, `likes`, `reads`, and `goes`.
- It does not support multi-sentence input, long documents, particle ambiguity, honorifics, tense variation, or complex word-order changes.

## Supported Examples

The app includes these preset sentences:

- 私は猫が好きです -> I like cats.
- 彼は学生です -> He is a student.
- これは本です -> This is a book.
- 私はりんごを食べます -> I eat an apple.
- 彼女は本を読みます -> She reads a book.
- 私は明日学校へ行きます -> I go to school tomorrow.
- 今日は暑いです -> It is hot today.
- ありがとう -> Thank you.

## Note

The output is controlled so that the visualization stays consistent for teaching. This app is not suitable for evaluating translation quality on arbitrary input.
